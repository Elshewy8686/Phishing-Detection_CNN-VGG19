# ============================
# An Enhanced Deep Learning Model for Phishing Detection Based on Bayesian Optimization and Hybrid CNN VGG19 Model
# ============================

# ---- Install deps
!pip -q install kaggle --upgrade
!pip -q install keras-tuner --upgrade
!pip -q install scikit-learn joblib

import os, sys, json, glob, zipfile, shutil, logging, subprocess, io, time
from typing import Optional, Dict
import numpy as np
import pandas as pd
from google.colab import files

# ML / metrics
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit, train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix)
from sklearn.linear_model import LogisticRegression

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, callbacks
import keras_tuner as kt
import joblib
import matplotlib.pyplot as plt

# ---- Repro / paths / logging
SEED = 2024
np.random.seed(SEED); tf.random.set_seed(SEED)
logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')

# ---- Config
OUTPUT_DIR     = "/content/phishing_workflow_artifacts"
DATASET_SLUG   = "shashwatwork/phishing-dataset-for-machine-learning"
IDENTIFIER_COLS = {"id","ID","Id","Url","URL","url","Index","index"}
LABEL_CANDS     = ["Result","result","Class","class","Label","label","Status","status","phishing","target","Target"]

# Train/Val/Test split
TRAIN_FRAC, VAL_FRAC, TEST_FRAC = 0.70, 0.15, 0.15

# Model defaults
BASE_FILTERS = 32
DROPOUT = 0.30
L2_REG = 5e-5
LR = 1e-3
EPOCHS = 120          # kept moderate for Colab
BATCH_SIZE = 64
EARLY_STOP = 10
REDUCE_PLATEAU = 5
MIN_LR = 1e-5

# KerasTuner (Bayesian) trials per model (tune lightly for Colab speed)
TUNER_TRIALS = 10
TUNER_EPOCHS = 40

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================
# 1) Kaggle auth + download
# ============================
def ensure_kaggle_auth_via_upload():
    kaggle_dir = "/root/.kaggle"
    os.makedirs(kaggle_dir, exist_ok=True)
    if not os.path.exists(f"{kaggle_dir}/kaggle.json"):
        print("📤 Upload kaggle.json (Kaggle → Account → Create API Token)")
        up = files.upload()
        if "kaggle.json" in up:
            with open(f"{kaggle_dir}/kaggle.json","wb") as f: f.write(up["kaggle.json"])
        else:
            for name, data in up.items():
                if name.lower().endswith(".json"):
                    with open(f"{kaggle_dir}/kaggle.json","wb") as f: f.write(data)
                    break
        if not os.path.exists(f"{kaggle_dir}/kaggle.json"):
            raise FileNotFoundError("kaggle.json not provided.")
        os.chmod(f"{kaggle_dir}/kaggle.json", 0o600)
    print("  Kaggle auth ready.")

def kaggle_download_and_extract(slug: str, out_root: str) -> str:
    os.makedirs(out_root, exist_ok=True)
    ret = subprocess.run(["kaggle","datasets","download","-d",slug,"-p",out_root,"-q"],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if ret.returncode != 0:
        print(ret.stderr)
        raise RuntimeError("Kaggle download failed. Accept dataset rules on Kaggle and re-run.")
    zips = glob.glob(os.path.join(out_root, "*.zip"))
    if not zips: raise FileNotFoundError("No .zip after Kaggle download.")
    def score(p):
        n = os.path.basename(p).lower()
        return (-(("phishing" in n)+("dataset" in n)+("learning" in n)+("shashwatwork" in n)), len(n))
    zip_path = sorted(zips, key=score)[0]
    extract_dir = os.path.join(out_root, "dataset")
    os.makedirs(extract_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(extract_dir)
    logging.info(f"Extracted to {extract_dir}")
    return extract_dir

def find_csv(dataset_dir: str) -> str:
    cands = glob.glob(os.path.join(dataset_dir, "**/*.csv"), recursive=True) + \
            glob.glob(os.path.join(dataset_dir, "*.csv"))
    if not cands: raise FileNotFoundError("No CSV found.")
    def rank(p):
        n = os.path.basename(p).lower()
        return (-(("phish" in n)+("dataset" in n)+("train" in n)+("data" in n)), len(n))
    return sorted(cands, key=rank)[0]

ensure_kaggle_auth_via_upload()
extract_dir = kaggle_download_and_extract(DATASET_SLUG, OUTPUT_DIR)
csv_path = find_csv(extract_dir)
print("Using CSV:", csv_path)

# ============================
# 2) Preprocessing
# ============================
df = pd.read_csv(csv_path)

# Remove nulls (rows with any NaN)
before = len(df)
df = df.dropna(axis=0).reset_index(drop=True)
after = len(df)
logging.info(f"Removed rows with NaNs: {before-after}")

# Identify label
label_col = next((c for c in LABEL_CANDS if c in df.columns), df.columns[-1])

# Encode label → {0,1}
y_raw = df[label_col]
if y_raw.dtype == "O" or str(y_raw.dtype).startswith("category"):
    y = LabelEncoder().fit_transform(y_raw.astype(str))
else:
    y = y_raw.to_numpy()
    uniq = set(np.unique(y))
    if uniq == {-1,1}:
        y = (y+1)//2
    elif not uniq.issubset({0,1}):
        y = LabelEncoder().fit_transform(y)
y = y.astype(int)

# Drop identifier columns & encode non-numeric features
X = df.drop(columns=[label_col]).copy()
for c in list(X.columns):
    if c in IDENTIFIER_COLS:
        X.drop(columns=[c], inplace=True, errors="ignore")
for c in X.columns:
    if not np.issubdtype(X[c].dtype, np.number):
        X[c] = LabelEncoder().fit_transform(X[c].astype(str))
X = X.astype(np.float32).values
feature_names = np.array([c for c in df.drop(columns=[label_col]).columns if c not in IDENTIFIER_COLS])

logging.info(f"Data shape before feature selection: X={X.shape}, positives={y.sum()} ({y.mean():.3f})")

# ============================
# 3) Feature Selection with BGA
#    (optimize 3-fold CV AUC using LogisticRegression as a fast proxy)
# ============================
def evaluate_subset(mask: np.ndarray, X_: np.ndarray, y_: np.ndarray) -> float:
    cols = np.where(mask==1)[0]
    if len(cols) == 0:
        return 0.5
    Xs = X_[:, cols]
    skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=SEED)
    aucs = []
    for tr, va in skf.split(Xs, y_):
        scaler = StandardScaler().fit(Xs[tr])
        Xtr = scaler.transform(Xs[tr])
        Xva = scaler.transform(Xs[va])
        clf = LogisticRegression(max_iter=200, n_jobs=None)
        clf.fit(Xtr, y_[tr])
        prob = clf.predict_proba(Xva)[:,1]
        aucs.append(roc_auc_score(y_[va], prob))
    return float(np.mean(aucs))

def binary_ga_feature_selection(X_: np.ndarray, y_: np.ndarray, pop=24, gens=15, p_mut=0.08, p_cx=0.7):
    n_feat = X_.shape[1]
    rng = np.random.default_rng(SEED)
    pop_masks = rng.integers(0, 2, size=(pop, n_feat), dtype=np.int8)
    fitness = np.array([evaluate_subset(m, X_, y_) for m in pop_masks])
    best_mask = pop_masks[np.argmax(fitness)].copy()
    best_score = float(np.max(fitness))
    for g in range(gens):
        # Selection (tournament)
        def tournament(k=3):
            idx = rng.choice(pop, size=k, replace=False)
            return pop_masks[idx[np.argmax(fitness[idx])]]
        new_pop = []
        while len(new_pop) < pop:
            p1, p2 = tournament(), tournament()
            if rng.random() < p_cx:
                cut = rng.integers(1, n_feat-1)
                c1 = np.concatenate([p1[:cut], p2[cut:]])
                c2 = np.concatenate([p2[:cut], p1[cut:]])
            else:
                c1, c2 = p1.copy(), p2.copy()
            # mutate
            mut1 = rng.random(n_feat) < p_mut
            mut2 = rng.random(n_feat) < p_mut
            c1[mut1] = 1 - c1[mut1]
            c2[mut2] = 1 - c2[mut2]
            new_pop.extend([c1, c2])
        pop_masks = np.array(new_pop[:pop], dtype=np.int8)
        fitness = np.array([evaluate_subset(m, X_, y_) for m in pop_masks])
        if fitness.max() > best_score:
            best_score = float(fitness.max())
            best_mask = pop_masks[np.argmax(fitness)].copy()
        logging.info(f"[BGA] Gen {g+1}/{gens} — best AUC={best_score:.4f}, selected={best_mask.sum()}")
    return best_mask, best_score

bga_mask, bga_auc = binary_ga_feature_selection(X, y, pop=24, gens=12)
np.save(os.path.join(OUTPUT_DIR, "bga_feature_mask.npy"), bga_mask)
logging.info(f"BGA done: selected {int(bga_mask.sum())}/{X.shape[1]} features (proxy AUC={bga_auc:.4f})")

X_sel = X[:, bga_mask==1]
logging.info(f"X after BGA: {X_sel.shape}")

# ============================
# 4) Data Splitting (70/15/15) + Z-Score (train stats)
# ============================
# First train vs (val+test)
X_train, X_tmp, y_train, y_tmp = train_test_split(
    X_sel, y, test_size=(1-TRAIN_FRAC), stratify=y, random_state=SEED
)
# Then split tmp into val and test (equal)
val_ratio = VAL_FRAC / (VAL_FRAC + TEST_FRAC)  # 0.5 if 15/15
X_val, X_test, y_val, y_test = train_test_split(
    X_tmp, y_tmp, test_size=(1-val_ratio), stratify=y_tmp, random_state=SEED
)

# Z-score normalize by training stats
scaler = StandardScaler().fit(X_train)
X_train = scaler.transform(X_train); X_val = scaler.transform(X_val); X_test = scaler.transform(X_test)

# Conv1D: (N, L, 1)
X_train_c = np.expand_dims(X_train, -1)
X_val_c   = np.expand_dims(X_val,   -1)
X_test_c  = np.expand_dims(X_test,  -1)
INPUT_LEN = X_train_c.shape[1]

# Save split for reproducibility
np.savez(os.path.join(OUTPUT_DIR, "split_70_15_15_indices.npz"),
         note="Order preserved by scikit splits; recompute masks by matching rows if needed.")

# ============================
# 5)(RNN, GRU, CNN, VGG19-1D, ResNet-1D, CNN-VGG19-1D)
# ============================
def build_rnn(hp=None):
    units = hp.Int("units", 32, 128, step=32) if hp else 64
    dr = hp.Float("dropout", 0.1, 0.5, step=0.1) if hp else 0.3
    inp = keras.Input(shape=(INPUT_LEN,1))
    x = layers.SimpleRNN(units, return_sequences=False)(inp)
    x = layers.Dropout(dr)(x)
    x = layers.Dense(64, activation="relu")(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    m = keras.Model(inp, out, name="RNN")
    lr = hp.Float("lr", 1e-4, 5e-3, sampling="log") if hp else LR
    m.compile(optimizer=keras.optimizers.Adam(lr), loss="binary_crossentropy",
              metrics=["accuracy", keras.metrics.Precision(), keras.metrics.Recall(), keras.metrics.AUC(name="auc")])
    return m

def build_gru(hp=None):
    units = hp.Int("units", 32, 128, step=32) if hp else 64
    dr = hp.Float("dropout", 0.1, 0.5, step=0.1) if hp else 0.3
    inp = keras.Input(shape=(INPUT_LEN,1))
    x = layers.GRU(units, return_sequences=False)(inp)
    x = layers.Dropout(dr)(x)
    x = layers.Dense(64, activation="relu")(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    m = keras.Model(inp, out, name="GRU")
    lr = hp.Float("lr", 1e-4, 5e-3, sampling="log") if hp else LR
    m.compile(optimizer=keras.optimizers.Adam(lr), loss="binary_crossentropy",
              metrics=["accuracy", keras.metrics.Precision(), keras.metrics.Recall(), keras.metrics.AUC(name="auc")])
    return m

def build_cnn1d(hp=None):
    f = hp.Int("filters", 16, 64, step=16) if hp else 32
    dr = hp.Float("dropout", 0.1, 0.5, step=0.1) if hp else 0.3
    inp = keras.Input(shape=(INPUT_LEN,1))
    x = layers.Conv1D(f, 5, padding="same", activation="relu")(inp)
    x = layers.MaxPooling1D(2)(x)
    x = layers.Conv1D(f*2, 3, padding="same", activation="relu")(x)
    x = layers.MaxPooling1D(2)(x)
    x = layers.Flatten()(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(dr)(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    m = keras.Model(inp, out, name="CNN1D")
    lr = hp.Float("lr", 1e-4, 5e-3, sampling="log") if hp else LR
    m.compile(optimizer=keras.optimizers.Adam(lr), loss="binary_crossentropy",
              metrics=["accuracy", keras.metrics.Precision(), keras.metrics.Recall(), keras.metrics.AUC(name="auc")])
    return m

def build_vgg19_1d(hp=None):
    bf = hp.Int("base_filters", 16, 64, step=16) if hp else BASE_FILTERS
    dr = hp.Float("dropout", 0.1, 0.5, step=0.1) if hp else DROPOUT
    l2 = hp.Float("l2", 1e-6, 1e-3, sampling="log") if hp else L2_REG
    lr = hp.Float("lr", 1e-4, 5e-3, sampling="log") if hp else LR
    reg = keras.regularizers.l2(l2)
    inp = keras.Input(shape=(INPUT_LEN,1))
    def block(x,f):
        x = layers.Conv1D(f,3,padding="same",activation="relu",kernel_regularizer=reg)(x)
        x = layers.Conv1D(f,3,padding="same",activation="relu",kernel_regularizer=reg)(x)
        return layers.MaxPooling1D(2)(x)
    x = block(inp, bf)
    x = block(x, bf*2)
    x = block(x, bf*4)
    x = block(x, bf*4)
    x = layers.Flatten()(x)
    x = layers.Dense(256, activation="relu", kernel_regularizer=reg)(x)
    x = layers.Dropout(dr)(x)
    x = layers.Dense(128, activation="relu", kernel_regularizer=reg)(x)
    x = layers.Dropout(dr)(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    m = keras.Model(inp, out, name="VGG19_1D")
    m.compile(optimizer=keras.optimizers.Adam(lr), loss="binary_crossentropy",
              metrics=["accuracy", keras.metrics.Precision(), keras.metrics.Recall(), keras.metrics.AUC(name="auc")])
    return m

def build_resnet1d(hp=None):
    f = hp.Int("filters", 16, 64, step=16) if hp else 32
    dr = hp.Float("dropout", 0.1, 0.5, step=0.1) if hp else 0.3
    inp = keras.Input(shape=(INPUT_LEN,1))
    x = layers.Conv1D(f, 7, padding="same", activation="relu")(inp)
    x = layers.MaxPooling1D(2)(x)
    # two residual blocks
    def res_block(x, f):
        s = x
        z = layers.Conv1D(f,3,padding="same",activation="relu")(x)
        z = layers.Conv1D(f,3,padding="same",activation=None)(z)
        z = layers.Add()([s,z])
        z = layers.Activation("relu")(z)
        return z
    x = res_block(x, f)
    x = res_block(x, f)
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dropout(dr)(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    m = keras.Model(inp, out, name="ResNet1D")
    lr = hp.Float("lr", 1e-4, 5e-3, sampling="log") if hp else LR
    m.compile(optimizer=keras.optimizers.Adam(lr), loss="binary_crossentropy",
              metrics=["accuracy", keras.metrics.Precision(), keras.metrics.Recall(), keras.metrics.AUC(name="auc")])
    return m

def build_cnn_vgg19(hp=None):
    # light hybrid: first CNN block then VGG-style head
    bf = hp.Int("base_filters", 16, 64, step=16) if hp else BASE_FILTERS
    dr = hp.Float("dropout", 0.1, 0.5, step=0.1) if hp else DROPOUT
    l2 = hp.Float("l2", 1e-6, 1e-3, sampling="log") if hp else L2_REG
    lr = hp.Float("lr", 1e-4, 5e-3, sampling="log") if hp else LR
    reg = keras.regularizers.l2(l2)
    inp = keras.Input(shape=(INPUT_LEN,1))
    x = layers.Conv1D(bf, 5, padding="same", activation="relu")(inp)
    x = layers.MaxPooling1D(2)(x)
    # VGG-ish tail
    def block(x,f):
        x = layers.Conv1D(f,3,padding="same",activation="relu",kernel_regularizer=reg)(x)
        x = layers.Conv1D(f,3,padding="same",activation="relu",kernel_regularizer=reg)(x)
        return layers.MaxPooling1D(2)(x)
    x = block(x, bf*2)
    x = block(x, bf*4)
    x = layers.Flatten()(x)
    x = layers.Dense(256, activation="relu", kernel_regularizer=reg)(x)
    x = layers.Dropout(dr)(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    m = keras.Model(inp, out, name="CNN_VGG19_1D")
    m.compile(optimizer=keras.optimizers.Adam(lr), loss="binary_crossentropy",
              metrics=["accuracy", keras.metrics.Precision(), keras.metrics.Recall(), keras.metrics.AUC(name="auc")])
    return m

MODEL_BUILDERS = {
    "RNN": build_rnn,
    "GRU": build_gru,
    "CNN": build_cnn1d,
    "VGG19": build_vgg19_1d,
    "ResNet-1D": build_resnet1d,
    "CNN-VGG19": build_cnn_vgg19,
}

# ============================
# 6) Bayesian Optimizer + Train best model per family
# ============================
def bayes_tune_and_train(name, build_fn):
    tuner = kt.BayesianOptimization(
        hypermodel=build_fn,
        objective=kt.Objective("val_auc", direction="max"),
        max_trials=TUNER_TRIALS,
        seed=SEED,
        directory=os.path.join(OUTPUT_DIR, "tuners"),
        project_name=f"{name}_bayes"
    )
    es  = callbacks.EarlyStopping(monitor="val_loss", patience=EARLY_STOP, restore_best_weights=True)
    rlp = callbacks.ReduceLROnPlateau(monitor="val_loss", patience=REDUCE_PLATEAU, factor=0.5, min_lr=MIN_LR)

    # mild class imbalance handling
    pos = y_train.sum(); neg = len(y_train) - pos
    class_weight = {0:1.0, 1: float(neg/max(1,pos))}

    tuner.search(X_train_c, y_train,
                 validation_data=(X_val_c, y_val),
                 epochs=TUNER_EPOCHS,
                 batch_size=BATCH_SIZE,
                 class_weight=class_weight,
                 callbacks=[es, rlp],
                 verbose=0)

    best_hp = tuner.get_best_hyperparameters(1)[0]
    model = build_fn(best_hp)
    history = model.fit(
        X_train_c, y_train,
        validation_data=(X_val_c, y_val),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        class_weight=class_weight,
        callbacks=[es, rlp],
        verbose=0
    )

    # Evaluate on TEST
    test_eval = model.evaluate(X_test_c, y_test, verbose=0)
    names = model.metrics_names  # ['loss','accuracy','precision','recall','auc']
    test_metrics = dict(zip(names, [float(v) for v in test_eval]))

    # sklearn metrics on threshold 0.5
    prob = model.predict(X_test_c, verbose=0).ravel()
    y_pred = (prob >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
    sk = dict(
        accuracy=float(accuracy_score(y_test, y_pred)),
        precision=float(precision_score(y_test, y_pred, zero_division=0)),
        recall=float(recall_score(y_test, y_pred, zero_division=0)),
        f1=float(f1_score(y_test, y_pred)),
        auc=float(roc_auc_score(y_test, prob)),
        tn=int(tn), fp=int(fp), fn=int(fn), tp=int(tp)
    )

    # Save artifacts
    out_dir = os.path.join(OUTPUT_DIR, name.replace(" ","_"))
    os.makedirs(out_dir, exist_ok=True)
    model.save(os.path.join(out_dir, f"{name}_best.keras"))
    pd.DataFrame(history.history).to_csv(os.path.join(out_dir, "history.csv"), index=False)
    with open(os.path.join(out_dir, "test_metrics_keras.json"), "w") as f: json.dump(test_metrics, f, indent=2)
    with open(os.path.join(out_dir, "test_metrics_sklearn.json"), "w") as f: json.dump(sk, f, indent=2)

    # Confusion matrix figure
    cm = np.array([[tn, fp],[fn, tp]])
    fig, ax = plt.subplots(figsize=(4.5,4))
    im = ax.imshow(cm, cmap="Blues")
    for (i,j),v in np.ndenumerate(cm):
        ax.text(j, i, str(v), ha='center', va='center', fontsize=11)
    ax.set_title(f"{name} — Test CM"); ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04); plt.tight_layout()
    fig.savefig(os.path.join(out_dir, "confusion_matrix.png"), dpi=150); plt.close(fig)

    return {
        "name": name,
        "val_auc_best": float(tuner.get_best_trials(1)[0].score),
        "test_loss": test_metrics["loss"],
        "test_accuracy": max(test_metrics.get("accuracy",0.0), sk["accuracy"]),
        "test_auc": max(test_metrics.get("auc",0.0), sk["auc"]),
        "test_precision": sk["precision"],
        "test_recall": sk["recall"],
        "test_f1": sk["f1"],
        "tn": sk["tn"], "fp": sk["fp"], "fn": sk["fn"], "tp": sk["tp"]
    }

results = []
for name, builder in MODEL_BUILDERS.items():
    logging.info(f"=== Tuning & training: {name} ===")
    res = bayes_tune_and_train(name, builder)
    results.append(res)
    logging.info(f"[{name}] Test Acc={res['test_accuracy']:.4f}  AUC={res['test_auc']:.4f}")

# Save scaler and BGA mask for deployment traceability
joblib.dump(StandardScaler().fit(X_train), os.path.join(OUTPUT_DIR, "scaler_example.pkl"))
np.save(os.path.join(OUTPUT_DIR, "bga_mask.npy"), bga_mask)

# ============================
# 7) Results table + summary
# ============================
res_df = pd.DataFrame(results).sort_values(by=["test_auc","test_accuracy"], ascending=False)
res_df.to_csv(os.path.join(OUTPUT_DIR, "final_results_table.csv"), index=False)

print("\n=== Final Results (sorted by Test AUC then Accuracy) ===")
display(res_df[["name","test_accuracy","test_auc","test_precision","test_recall","test_f1","test_loss","tn","fp","fn","tp"]])

print("\nArtifacts saved in:", OUTPUT_DIR)
print(os.listdir(OUTPUT_DIR))
